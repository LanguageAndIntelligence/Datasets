README

We run all experiments on Google Colab with a regular, free user account.
Given pre-computed features, the notebook code takes on average 2 minutes to finish running.

Files:

+ cross_validation_dataset.pkl : Annotated dataset to cross-validate and train learning-to-rank models.
+ stsbenchmarks-all.pkl : STS Benchmark with pre-computed features.
+ parabank-eval-all.pkl : ParaBank evaluation dataset with pre-computed features.

+ STS_by_HumanRanking.csv : Sorted STS Benchmark dataset by human annotated semantic similarity ranking.
+ STS_by_RawModel.csv : Sorted STS Benchmark dataset by F1 combination between Raw score and human annotated semantic similarity ranking.
+ STS_by_IndexModel.csv : Sorted STS Benchmark dataset by F1 combination between Index score and human annotated semantic similarity ranking.

+ ParaB_by_HumanRanking.csv : Sorted ParaBank Evaluation dataset by human annotated semantic similarity ranking.
+ ParaB_by_RawModel.csv : Sorted ParaBank Evaluation dataset by F1 combination between Raw score and human annotated semantic similarity ranking.
+ ParaB_by_IndexModel.csv: Sorted ParaBank Evaluation dataset by F1 combination between Index score and human annotated semantic similarity ranking.

+ ParaBank2_6K_sample.csv : A sample of 6,000 reference/paraphrase pairs in ParaBank 2.0. The full set with 19 million reference sentences is available on the author's website.